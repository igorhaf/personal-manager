package com.gestaopessoal.personal_manager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersonalManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
