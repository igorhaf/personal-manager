package com.gestaopessoal.personal_manager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PersonalManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(PersonalManagerApplication.class, args);
	}

}
